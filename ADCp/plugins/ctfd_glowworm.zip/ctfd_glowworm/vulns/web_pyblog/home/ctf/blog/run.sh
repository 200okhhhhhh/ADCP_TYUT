
nohup python /home/ctf/blog/manage.py runserver 0.0.0.0:8000 >> /home/ctf/blog/log.txt &
