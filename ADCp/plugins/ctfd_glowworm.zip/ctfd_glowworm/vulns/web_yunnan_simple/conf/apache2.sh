#!/bin/bash
ulimit -t 5
# ulimit -u 5
service apache2 start;