<?php
	$file=$_GET['file'];
	include $file;
?>
<!-- banner -->
	<div class="banner1">
	</div>
<!-- //banner -->
<!-- about -->
	<div class="about">
		<div class="container">
			<ol class="breadcrumb breadco">
			  <li><a href="./index.php">Home</a></li>
			  <li class="active">About Us</li>
			</ol>
			<div class="about-grids">
				<div class="col-md-6 about-grid">
					<h3>About Us</h3>
					<img src="images/banner.jpg" alt=" " class="img-responsive" />
					<h4>Neque porpro quisquam est, qui dolorem ipsum quia dolor sit amet aliquid ex ea consectetur</h4>
					<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam 
						corporis suscipit laboriosam, nisi ut aliquid ex ea consectetur, adipisci 
						velit, sed quia non numquam eius modi commodi consequatur.</p>
				</div>
				<div class="col-md-6 about-grid">
					<h3>Our History</h3>
					<div class="about-gd">
						<div class="about-gd-left">
							<h4>1995 -</h4>
						</div>
						<div class="about-gd-right">
							<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam 
								corporis suscipit laboriosam.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="about-gd">
						<div class="about-gd-left">
							<h4>2000 -</h4>
						</div>
						<div class="about-gd-right">
							<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam 
								corporis suscipit laboriosam.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="about-gd">
						<div class="about-gd-left">
							<h4>2013 -</h4>
						</div>
						<div class="about-gd-right">
							<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam 
								corporis suscipit laboriosam.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="about-gd">
						<div class="about-gd-left">
							<h4>2015 -</h4>
						</div>
						<div class="about-gd-right">
							<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam 
								corporis suscipit laboriosam.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="about-gd">
						<div class="about-gd-left">
							<h4>Today</h4>
						</div>
						<div class="about-gd-right">
							<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam 
								corporis suscipit laboriosam.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //about -->
<!-- history -->
	<div class="history">
		<div class="container">
			<div class="col-md-6 history-left">	
				<h3>Our Standards</h3>
				<div class="history-left-grid">
					<p><i class="glyphicon glyphicon-calendar" aria-hidden="true"></i>21.9.2015</p>
					<h4>consequatur aut perferendis</h4>
					<p class="aut">Itaque earum rerum hic tenetur a sapiente delectus,
						ut aut reiciendis voluptatibus maiores alias consequatur voluptates repudiandae sint et 
						molestiae non recusandae aut perferendis.</p>
				</div>
				<div class="history-left-grid">
					<p><i class="glyphicon glyphicon-calendar" aria-hidden="true"></i>28.9.2015</p>
					<h4>consequatur aut perferendis</h4>
					<p class="aut">Itaque earum rerum hic tenetur a sapiente delectus,
						ut aut reiciendis voluptatibus maiores alias consequatur voluptates repudiandae sint et 
						molestiae non recusandae aut perferendis.</p>
				</div>
				<div class="history-left-grid">
					<p><i class="glyphicon glyphicon-calendar" aria-hidden="true"></i>03.8.2015</p>
					<h4>consequatur aut perferendis</h4>
					<p class="aut">Itaque earum rerum hic tenetur a sapiente delectus,
						ut aut reiciendis voluptatibus maiores alias consequatur voluptates repudiandae sint et 
						molestiae non recusandae aut perferendis.</p>
				</div>
			</div>
			<div class="col-md-6 history-right">
				<h3>What We Offer</h3>
				<h4>voluptatibus maiores alias</h4>
				<p>To take a trivial example, which of us ever undertakes laborious physical 
					exercise, except to obtain some advantage from it? But who has any right to 
					find fault with a man who chooses to enjoy a pleasure.</p>
				<ul>
					<li><a href="#">recusandae aut perferendis</a></li>
					<li><a href="#">voluptatibus maiores alias</a></li>
					<li><a href="#">molestiae non recusandae</a></li>
					<li><a href="#">alias consequatur voluptates</a></li>
					<li><a href="#">tenetur a sapiente delectus</a></li>
					<li><a href="#">earum rerum hic tenetur</a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //history -->
<?php
	include 'footer.php';
?>
