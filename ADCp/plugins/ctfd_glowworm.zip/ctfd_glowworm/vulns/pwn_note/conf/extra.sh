#!/bin/bash
/etc/init.d/xinetd start;
/etc/init.d/ssh start;
sleep infinity;